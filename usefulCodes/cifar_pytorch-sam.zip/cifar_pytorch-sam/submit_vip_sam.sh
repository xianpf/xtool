#!/bin/sh

#SBATCH -o vip_sam_train.txt
#SBATCH --job-name=vip_sam
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=2
#SBATCH -w node6
srun --mpi=pmi2 python main_vip_sam.py
