#!/bin/sh

#SBATCH -o resnet_train.txt
#SBATCH --job-name=resnet
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=2
#SBATCH -w node6
srun --mpi=pmi2 python main.py
