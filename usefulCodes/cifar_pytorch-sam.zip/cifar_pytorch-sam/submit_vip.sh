#!/bin/sh

#SBATCH -o vip_train.txt
#SBATCH --job-name=vip
#SBATCH --gres=gpu:2
#SBATCH --cpus-per-task=2
#SBATCH -w node5
srun --mpi=pmi2 python main_vip.py
